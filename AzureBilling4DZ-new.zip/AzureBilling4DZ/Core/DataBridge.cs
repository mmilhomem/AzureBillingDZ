﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net;
using System.IO;

namespace AzureBilling4DZ.Core
{
    class DataBridge
    {

        #region vars
        private string strEANumber = string.Empty;
        private string strEAKey = string.Empty;
        private string strBearerToken = string.Empty;
        //private string strUrl = string.Format(@"{0}?month={{1}}&type={{2}}", ConfigurationManager.AppSettings["UsageReportAPIUrl"]);
        private string strUrl = string.Format(@"{0}?month={{1}}&type={{2}}", "https://ea.azure.com/rest/{0}/usage-report");
        #endregion

        #region Get and Set
        public string StrEAKey
        {
            get
            {
                return strEAKey;
            }

            set
            {
                strEAKey = value;
                strBearerToken = string.Concat("bearer ", value);
            }
        }
        public string StrEANumber
        {
            get
            {
                return strEANumber;
            }

            set
            {
                strEANumber = value;
            }
        }
        public string StrBearerToken
        {
            get
            {
                return strBearerToken;
            }
        }
        #endregion

        #region Enumerators
        public enum UsageReportType
        {
            Summary,
            Detail
        }

        public enum UsageReportRetroactiveProcess
        {
            No,
            Yes
        }
        #endregion

        #region Constructors
        public DataBridge()
        {
            this.StrEANumber = string.Empty;
            this.StrEAKey = string.Empty;
        }

        public DataBridge(string strLocalEANumber, string strLocalEAKey)
        {
            this.StrEANumber = strLocalEANumber;
            this.StrEAKey = strLocalEAKey;
        }
        #endregion

        public StreamReader GetUsageReport(DateTime dtReportDate, UsageReportType type)
        {
            string url = string.Format(this.strUrl, this.StrEANumber, dtReportDate, type);

            WebRequest request = WebRequest.Create(url);
            request.Headers.Add("authorization", this.StrBearerToken);
            //request.Headers.Add("api-version", ConfigurationManager.AppSettings["UsageReportAPIVersion"].ToString());
            request.Headers.Add("api-version", "1.0");

            HttpWebResponse response = null;
            try { response = (HttpWebResponse)request.GetResponse(); }
            catch (WebException ex) { response = (HttpWebResponse)ex.Response; }

            StreamReader reader = null;
            try { reader = new StreamReader(response.GetResponseStream()); } 
            catch(Exception ex) { } 
            return reader;
        }
    }
}
