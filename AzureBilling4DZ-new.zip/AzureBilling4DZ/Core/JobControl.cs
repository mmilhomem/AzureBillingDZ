﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Globalization;

namespace AzureBilling4DZ.Core
{
    class JobControl
    {

        private DateTime dtReportStartDate;
        int iReset = 0;
        public DateTime ReportStartDate
        {
            get
            {
                return dtReportStartDate;
            }

            set
            {
                dtReportStartDate = value;
            }
        }

        public JobControl()
        {
            try
            {
                iReset = int.Parse(ConfigurationManager.AppSettings["Reset"]);
                int iDay, iMonth, iYear;
                int.TryParse(ConfigurationManager.AppSettings["UsageReportStartMonth"], out iMonth);
                int.TryParse(ConfigurationManager.AppSettings["UsageReportStartYear"], out iYear);
                iDay = iMonth;
                this.ReportStartDate = new DateTime(iYear, iMonth, iDay);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method JobControl::Constructor\r\n \t" + ex.Message);
            }
        }

        #region private methods
        public void Collect()
        {
            Core.DataPersistence dp = new Core.DataPersistence();
            List<object[]> eaContracts = dp.GetEAContracts();
            foreach (object[] objEA in eaContracts)
            {
                Core.DataBridge db = new Core.DataBridge(objEA[0].ToString(), objEA[1].ToString());
                DateTime dtLastReportDate = DateTime.MinValue;
                DateTime.TryParse(objEA[3].ToString(), out dtLastReportDate);

                if (iReset > 0)
                    dp.ResetBillingDetail(db.StrEANumber, this.ReportStartDate.Month.ToString());
                else if (dtLastReportDate.CompareTo(this.ReportStartDate) > 0)
                    this.ReportStartDate = dtLastReportDate;

                while (this.ReportStartDate.Month <= DateTime.Today.Month && ReportStartDate.Year <= DateTime.Today.Year)
                {
                    SaveSummaryReport(dp, db);
                    SaveDetailReport(dp, db);
                    this.ReportStartDate = ReportStartDate.AddMonths(1);
                }
                dp.UpdateLastReportDate(db.StrEANumber);
            }
            dp.Disconnect();
        }

        private void SaveSummaryReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            StreamReader readerSummary = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Summary);
            string[] arrRow = new string[16];

            int i = 3;
            while (!readerSummary.EndOfStream && i<=arrRow.Length-1)
            {
                try
                {
                    string[] strRow = readerSummary.ReadLine().Replace("\",\"", "¦").Replace("\"", "").Replace("$", "").Split('¦');
                    if (strRow.Length > 1)
                    {
                        DateTime dt;
                        if (DateTime.TryParse(strRow[strRow.Length-1], out dt) && i<arrRow.Length-1) i++;
                        arrRow[i] = strRow[strRow.Length - 1].Replace(",","");
                    }
                    i++;

                }
                catch (Exception ex) { Console.WriteLine("Error Occured at method JobControl::SaveSummaryReport\r\n \t" + ex.Message); }
            }
            arrRow[0] = db.StrEANumber;
            string strDate = arrRow.Last();
            if (strDate != null)
                if (dp.ResetBillingDaySummary(db.StrEANumber, strDate) >= 0)
                    dp.SaveSummaryReport(arrRow);
        }

        private void SaveDetailReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            StreamReader readerDetail = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Detail);
            List<string[]> arrDayRows = new List<string[]>();
            string strDates = string.Empty;
            DateTime dtDayReportDetailLastDate = dp.GetLastDate();

            while (!readerDetail.EndOfStream)
            {
                try
                {
                    string strStream = readerDetail.ReadLine().Replace("\",\"", "¦");
                    string strRow = string.Concat(db.StrEANumber + "¦", strStream.Replace("\"", ""));
                    string[] arrRow = strRow.Split('¦');
                    
                    if (arrRow.Length == 30)
                    {
                        DateTime dtReportDate;
                        if (DateTime.TryParse(arrRow[7].ToString(), out dtReportDate))
                            if (dtReportDate.CompareTo(dtDayReportDetailLastDate) > 0)
                                arrDayRows.Add(arrRow);
                    }
                }
                catch (Exception ex){Console.WriteLine("Error Occured at method JobControl::SaveDetailReport\n" + ex.Message);}
            }

            if (arrDayRows.Count > 0)
            {
                foreach (string[] strRow in arrDayRows)
                    dp.SaveDayDetailReport(strRow);
                Console.WriteLine("EA " + db.StrEANumber + ": " + arrDayRows.Count.ToString() + " Billing Detail records loaded (Month " + ReportStartDate.Month.ToString() + ")");
            }
        }
        #endregion

    }
}
