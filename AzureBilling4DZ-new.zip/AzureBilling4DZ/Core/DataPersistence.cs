﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace AzureBilling4DZ.Core
{
    class DataPersistence
    {
        #region vars
        private string strConnString = string.Empty;
        private SqlConnection sqlConn = null;
        private SqlCommand sqlCom = null;
        #endregion

        #region  Constructors
        public DataPersistence()
        {
            this.strConnString = ConfigurationManager.ConnectionStrings["AzureSQLDB"].ToString();
            this.Connect();
        }
        #endregion

        #region Private Methods
        private void Connect()
        {
            try {
                if (!string.IsNullOrEmpty(strConnString.Trim())) {
                    this.sqlConn = new SqlConnection(this.strConnString);
                    this.sqlConn.Open();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::GetEAContracts\n" + ex.Message);
            }
        }

        public void Disconnect()
        {
            if (sqlConn.State != System.Data.ConnectionState.Closed)
                sqlConn.Close();
        }
        #endregion

        #region Public Methods

        public DateTime GetLastDate()
        {
            DateTime dtLastReportDate = DateTime.MinValue;
            try
            {
                this.sqlCom = new SqlCommand("Select top 1 date from BillingDetail order by date desc", this.sqlConn);
                SqlDataReader sqlDr = this.sqlCom.ExecuteReader();
                sqlDr.Read();
                object[] arrRows = new object[sqlDr.FieldCount];
                if (sqlDr.HasRows)
                {
                    sqlDr.GetValues(arrRows);
                    DateTime.TryParse(arrRows[arrRows.Length - 1].ToString(), out dtLastReportDate);
                }
                sqlDr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::GetLastDate\n" + ex.Message);
            }
            return dtLastReportDate;
        }


        public List<object[]> GetEAContracts()
        {
            List<object[]> objStr = new List<object[]>();
            try
            {
                this.sqlCom = new SqlCommand("Select * From EAContracts where IsActive = 1", this.sqlConn);
                SqlDataReader sqlDr = this.sqlCom.ExecuteReader();
                while (sqlDr.Read())
                {
                    object[] arrRows = new object[sqlDr.FieldCount];
                    sqlDr.GetValues(arrRows);
                    objStr.Add(arrRows);
                }
                sqlDr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::GetEAContracts\n" + ex.Message);
            }

            return objStr;
        }

        public int UpdateLastReportDate(string strEANumber)
        {
            int iReturn = -1;
            try
            {
                string strCommand = string.Format("Update EAContracts Set LastReportDate=(select distinct top 1 date from BillingDetail order by date desc) where EANumber = {0}", strEANumber);
                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex) { Console.WriteLine("Error Occured at method DataPersistence::UpdateLastReportDate\n" + ex.Message); }
            return iReturn;
        }

        public int ResetBillingDaySummary(string strEANumber, string strDay)
        {
            int iReturn = -1;
            try
            {
                string strCommand = string.Format("Delete From BillingSummary Where EANumber={0} and ReportGenerationDate='{1}'", strEANumber, strDay);
                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::ResetBillingDaySummary\n" + ex.Message);
            }
            return iReturn;
        }

        public int ResetBillingDetail(string strEANumber, string strMonth)
        {
            int iReturn = -1;
            try
            {
                string strCommand = string.Format("Delete From BillingDetail Where EANumber={0} and month >= {1}", strEANumber, strMonth);
                this.sqlCom = new SqlCommand(strCommand, sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::ResetBillingDayDetail\n" + ex.Message);
            }
            return iReturn;
        }


        public int SaveDayDetailReport(string[] arrRow)
        {
            int iReturn = -1;
            try
            {
                string strCommand = "Insert into BillingDetail "+
                                    "values({0},'{1}','{2}','{3}',{4}," + 
                                    "'{5}','{6}','{7}',{8},{9},{10}," +
                                    "'{11}','{12}','{13}','{14}','{15}'," + 
                                    "'{16}','{17}','{18}','{19}','{20}'," +
                                    "'{21}','{22}','{23}','{24}','{25}'," +
                                    "'{26}','{27}','{28}','{29}')";

                strCommand = string.Format(strCommand, arrRow);

                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::SaveDayDetailReport\n" + ex.Message);
            }
            return iReturn;
        }

        public int SaveSummaryReport(string[] arrRow)
        {
            int iReturn = -1;
            try
            {
                string strCommand = "Insert into BillingSummary " +
                                    "values('{0}','{1}','{2}','{3}','{4}'," +
                                    "'{5}','{6}','{7}','{8}','{9}','{10}'," +
                                    "'{11}','{12}','{13}','{14}','{15}')";

                strCommand = string.Format(strCommand, arrRow);

                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::SaveSummaryReport\n" + ex.Message);
            }
            return iReturn;
        }

        #endregion
    }
}
