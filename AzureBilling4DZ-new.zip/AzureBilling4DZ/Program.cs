﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using System.IO;
using System.Globalization;
using System.Configuration;


namespace AzureBilling4DZ
{
    class Program
    {
        static void Main()
        {
            var host = new JobHost();
            Functions.CollectReports(null, null); 
            host.RunAndBlock();
        }
    }
}
