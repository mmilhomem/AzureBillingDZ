﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Globalization;

namespace AzureBilling4DZ.Core
{
    class JobControl
    {

        private DateTime dtReportStartDate;
        int iReset = 0;
        public DateTime ReportStartDate
        {
            get
            {
                return dtReportStartDate;
            }

            set
            {
                dtReportStartDate = value;
            }
        }

        public JobControl()
        {
            try
            {
                iReset = int.Parse(ConfigurationManager.AppSettings["Reset"]);
                int iDay, iMonth, iYear;
                int.TryParse(ConfigurationManager.AppSettings["UsageReportStartMonth"], out iMonth);
                int.TryParse(ConfigurationManager.AppSettings["UsageReportStartYear"], out iYear);
                iDay = iMonth;
                this.ReportStartDate = new DateTime(iYear, iMonth, iDay);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method JobControl::Constructor\r\n \t" + ex.Message);
            }
        }

        #region private methods
        public void Collect()
        {
            Core.DataPersistence dp = new Core.DataPersistence();
            List<object[]> eaContracts = dp.GetEAContracts();
            if (eaContracts.Count > 0)
            {
                foreach (object[] objEA in eaContracts)
                {
                    Core.DataBridge db = new Core.DataBridge(objEA[0].ToString(), objEA[1].ToString());
                    DateTime dtLastReportDate = DateTime.MinValue;
                    DateTime.TryParse(objEA[3].ToString(), out dtLastReportDate);

                    if (iReset > 0)
                    {
                        Console.WriteLine("Reset activated! Truncating...");
                        dp.ResetBillingDetail(db.StrEANumber);
                        Console.WriteLine("Legacy data cleaned: EA " + db.StrEANumber);
                    }
                    else if (dtLastReportDate.CompareTo(this.ReportStartDate) > 0)
                    {
                        Console.WriteLine("EA " + db.StrEANumber + ". Loading only data with date greater then " + this.ReportStartDate.Month.ToString() + ". Last time report run. Configure Reset Parameter if you expect reload legacy data.");
                        this.ReportStartDate = dtLastReportDate;
                    }

                    while (this.ReportStartDate.CompareTo(DateTime.Today) <= 0)
                    {
                        if (SaveSummaryReport(dp, db) > 0)
                            SaveDetailReport(dp, db);
                        this.ReportStartDate = ReportStartDate.AddMonths(1);
                    }
                    dp.UpdateLastReportDate(db.StrEANumber);
                }
            }
            dp.Disconnect();
        }

        private int SaveSummaryReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            int iR = -1;
            StreamReader readerSummary = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Summary);
            if (!readerSummary.BaseStream.CanWrite)
            {
                string[] arrRow = new string[17];
                arrRow[0] = db.StrEANumber;

                int i = 4;
                while (!readerSummary.EndOfStream && i <= arrRow.Length - 1)
                {
                    try
                    {
                        string[] strRow = readerSummary.ReadLine().Replace("\",\"", "¦").Replace("\"", "").Replace("$", "").Split('¦');
                        if (strRow.Length > 1)
                        {
                            if (strRow[0].Trim() != "")
                            {
                                DateTime dt;
                                if (DateTime.TryParse(strRow[strRow.Length - 1], out dt))
                                {
                                    if (i < arrRow.Length - 1) i++;
                                    arrRow[2] = dt.Year.ToString();
                                    arrRow[3] = dt.Month.ToString();
                                }
                                arrRow[i] = strRow[strRow.Length - 1].Replace(",", "");
                                i++;
                            }
                        }
                    }
                    catch (Exception ex) { Console.WriteLine("Error Occured at method JobControl::SaveSummaryReport\r\n \t" + ex.Message); }
                }

                string strDate = arrRow.Last();
                if (strDate != null)
                    if (dp.ResetBillingDaySummary(db.StrEANumber, strDate, arrRow[4]) >= 0)
                        iR = dp.SaveSummaryReport(arrRow);
            }
            return iR;
        }

        private void SaveDetailReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            StreamReader readerDetail = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Detail);

            if (!readerDetail.BaseStream.CanWrite)
            {
                List<string[]> arrDayRows = new List<string[]>();
                string strDates = string.Empty;
                DateTime dtDayReportDetailLastDate = dp.GetLastDate();

                while (!readerDetail.EndOfStream)
                {
                    try
                    {
                        string strStream = readerDetail.ReadLine().Replace("\",\"", "¦");
                        string strRow = string.Concat(db.StrEANumber + "¦", strStream.Replace("\"", ""));
                        string[] arrRow = strRow.Split('¦');

                        if (arrRow.Length > 2)
                        {
                            DateTime dtReportDate;
                            if (DateTime.TryParse(arrRow[7].ToString(), out dtReportDate))
                                if (dtReportDate.CompareTo(dtDayReportDetailLastDate) > 0)
                                    arrDayRows.Add(arrRow);
                        }
                    }
                    catch (Exception ex) { Console.WriteLine("Error Occured at method JobControl::SaveDetailReport\n" + ex.Message); }
                }

                if (arrDayRows.Count > 0)
                {
                    foreach (string[] strRow in arrDayRows)
                        dp.SaveDayDetailReport(strRow);
                    Console.WriteLine("EA " + db.StrEANumber + ": " + arrDayRows.Count.ToString() + " of billing records loaded (Month " + ReportStartDate.Month.ToString() + ")");
                }
            }
        }
        #endregion

    }
}
