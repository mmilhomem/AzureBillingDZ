﻿using Microsoft.Azure.WebJobs;

namespace AzureBilling4DZ
{
    class Program
    {
        static void Main()
        {
            var host = new JobHost();
            Functions.CollectReports(null, null);
        }
    }
}
