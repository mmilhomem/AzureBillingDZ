﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;

namespace AzureBilling4DZ
{
    public class Functions
    {
        public static void CollectReports([QueueTrigger("queue")] string message, TextWriter log)
        {
            try
            {
                DateTime dtStart = DateTime.Now;
                Console.WriteLine("Starting Usage Report Extraction...");
                Core.JobControl jc = new Core.JobControl();
                jc.Collect();
                string strTimeDiff = DateTime.Now.Subtract(dtStart).TotalMinutes.ToString().Substring(0,5);
                string strMessage = "Report Collected in " + DateTime.Today.ToLongDateString() + " " + DateTime.Now.ToLongTimeString() + ". Elapsed time: " + strTimeDiff + " min\r\n";
                Console.WriteLine(strMessage);
            }
            catch (Exception ex)
            { Console.WriteLine("Error Occurred at method Functions::CollectReports\n" + ex.Message); }

        }
    }
}
