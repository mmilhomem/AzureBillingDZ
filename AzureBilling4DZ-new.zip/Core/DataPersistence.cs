﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace AzureBilling4DZ.Core
{
    class DataPersistence
    {

        #region vars
        private string strConnString = string.Empty;
        private SqlConnection sqlConn = null;
        private SqlCommand sqlCom = null;
        #endregion

        #region  Constructors
        public DataPersistence()
        {
            this.strConnString = ConfigurationManager.ConnectionStrings["AzureSQLDB"].ToString();
            //this.strConnString = Environment.GetEnvironmentVariable("SQLAZURECONNSTR_AzureSQLDB");
            this.Connect();
        }
        #endregion

        #region Private Methods
        private void Connect()
        {
            try {
                if (!string.IsNullOrEmpty(strConnString.Trim())) {
                    this.sqlConn = new SqlConnection(this.strConnString);
                    this.sqlConn.Open();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::GetEAContracts\n" + ex.Message);
            }
        }

        public void Disconnect()
        {
            if (sqlConn.State != System.Data.ConnectionState.Closed)
                sqlConn.Close();
        }
        #endregion

        #region Public Methods

        public List<object[]> GetEAContracts()
        {
            List<object[]> objStr = new List<object[]>();
            try
            {
                this.sqlCom = new SqlCommand("Select * From EAContracts", this.sqlConn);
                SqlDataReader sqlDr = this.sqlCom.ExecuteReader();
                while (sqlDr.Read())
                {
                    object[] arrRows = new object[sqlDr.FieldCount];
                    sqlDr.GetValues(arrRows);
                    objStr.Add(arrRows);
                }
                sqlDr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::GetEAContracts\n" + ex.Message);
            }

            return objStr;
        }

        public int ResetBillingDaySummary(string strEANumber, string strDay)
        {
            int iReturn = -1;
            try
            {
                string strCommand = string.Format("Delete From BillingSummary Where EANumber={0} and ReportGenerationDate='{1}'", strEANumber, strDay);
                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::ResetBillingDaySummary\n" + ex.Message);
            }
            return iReturn;
        }

        public int ResetBillingDayDetail(string strEANumber, DateTime dtReportDate, DataBridge.UsageReportRetroactiveProcess urp)
        {
            int iReturn = -1;
            try
            {
                string strComplement = (urp == DataBridge.UsageReportRetroactiveProcess.No ? " and Day={2}" : "");
                string[] args = new string[3];
                args[0] = strEANumber;
                args[1] = dtReportDate.Month.ToString();
                args[2] = dtReportDate.Day.ToString();
                string strCommand = string.Format("Delete From BillingDetail Where EANumber={0} and month={1}" + strComplement, args);
                this.sqlCom = new SqlCommand(strCommand, sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::ResetBillingDayDetail\n" + ex.Message);
            }
            return iReturn;
        }

        public int SaveDayDetailReport(string[] arrRow)
        {
            int iReturn = -1;
            try
            {
                string strCommand = "Insert into BillingDetail "+
                                    "values({0},'{1}','{2}','{3}',{4}," + 
                                    "'{5}','{6}','{7}',{8},{9},{10}," +
                                    "'{11}','{12}','{13}','{14}','{15}'," + 
                                    "'{16}','{17}','{18}','{19}','{20}'," +
                                    "'{21}','{22}','{23}','{24}','{25}'," +
                                    "'{26}','{27}','{28}','{29}')";

                strCommand = string.Format(strCommand, arrRow);

                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::SaveDayDetailReport\n" + ex.Message);
            }
            return iReturn;
        }

        public int SaveSummaryReport(string[] arrRow)
        {
            int iReturn = -1;
            try
            {
                string strCommand = "Insert into BillingSummary " +
                                    "values('{0}','{1}','{2}','{3}','{4}'," +
                                    "'{5}','{6}','{7}','{8}','{9}','{10}'," +
                                    "'{11}','{12}','{13}','{14}','{15}')";

                strCommand = string.Format(strCommand, arrRow);

                this.sqlCom = new SqlCommand(strCommand, this.sqlConn);
                iReturn = sqlCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured at method DataPersistence::SaveSummaryReport\n" + ex.Message);
            }
            return iReturn;
        }

        #endregion
    }
}
