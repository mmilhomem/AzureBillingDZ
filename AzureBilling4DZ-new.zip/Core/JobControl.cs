﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Globalization;

namespace AzureBilling4DZ.Core
{
    class JobControl
    {

        private DateTime dtReportStartDate;
        private Core.DataBridge.UsageReportRetroactiveProcess rp = DataBridge.UsageReportRetroactiveProcess.No;

        public DateTime ReportStartDate
        {
            get
            {
                return dtReportStartDate;
            }

            set
            {
                dtReportStartDate = value;
            }
        }

        internal DataBridge.UsageReportRetroactiveProcess Rp
        {
            get
            {
                return rp;
            }

            set
            {
                rp = value;
            }
        }

        public JobControl(Core.DataBridge.UsageReportRetroactiveProcess isRetroactive)
        {
            try
            {
                this.ReportStartDate = DateTime.Parse(ConfigurationManager.AppSettings["UsageReportStartDateMDY"].ToString(), new CultureInfo("en-US"));
                //this.ReportStartDate = DateTime.Parse(Environment.GetEnvironmentVariable("APPSETTING_UsageReportStartDateMDY"), new CultureInfo("en-US"));
                this.Rp = isRetroactive;
            }
            catch (Exception ex) { }
        }

        #region private methods
        public void Collect()
        {
            Core.DataPersistence dp = new Core.DataPersistence();
            while (this.ReportStartDate.Month <= DateTime.Today.Month)
            {
                List<object[]> eaContracts = dp.GetEAContracts();
                foreach (object[] objEA in eaContracts)
                {
                    Core.DataBridge db = new Core.DataBridge(objEA[0].ToString(), objEA[1].ToString());
                    SaveSummaryReport(dp, db);
                    SaveDetailReport(dp, db);
                }
                //ConfigurationManager.AppSettings["UsageReportStartDateMDY"] = DateTime.Parse(ConfigurationManager.AppSettings["UsageReportStartDateMDY"].ToString(), new CultureInfo("en-US")).AddMonths(1).ToString();
                this.ReportStartDate = this.ReportStartDate.AddMonths(1);
                //this.ReportStartDate = new DateTime(this.ReportStartDate.Year, this.ReportStartDate.Month, this.ReportStartDate.Month);
                //Environment.SetEnvironmentVariable("APPSETTING_UsageReportStartDateMDY", this.ReportStartDate.ToShortDateString());
            }
            dp.Disconnect();
        }

        private void SaveSummaryReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            StreamReader readerSummary = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Summary);
            string[] arrRow = new string[16];

            int i = 3;
            while (!readerSummary.EndOfStream)
            {
                try
                {
                    string[] strRow = readerSummary.ReadLine().Replace("\",\"", "¦").Replace("\"", "").Replace("$", "").Split('¦');
                    if(strRow.Length > 1)
                        arrRow[i] = strRow[strRow.Length-1];
                    i++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error Occured at method JobControl::SaveSummaryReport\r\n \t" + ex.Message);
                }
            }
            arrRow[0] = db.StrEANumber;

            string strDate = arrRow.Last();
            if (dp.ResetBillingDaySummary(db.StrEANumber, strDate) >= 0)
            {
                dp.SaveSummaryReport(arrRow);
            }
        }

        private void SaveDetailReport(Core.DataPersistence dp, Core.DataBridge db)
        {
            StreamReader readerDetail = db.GetUsageReport(this.ReportStartDate, Core.DataBridge.UsageReportType.Detail);

            List<string[]> arrDayRows = new List<string[]>();

            if (this.Rp == DataBridge.UsageReportRetroactiveProcess.No)
            {
                while (!readerDetail.EndOfStream)
                {
                    try
                    {
                        string strStream = readerDetail.ReadLine().Replace("\",\"", "¦");
                        string strRow = string.Concat(db.StrEANumber + "¦", strStream.Replace("\"",""));
                        string[] arrRow = strRow.Split('¦');
                        if (arrRow.Length == 30)
                        {
                            int iCurrentDay;
                            if (int.TryParse(arrRow[9], out iCurrentDay) && iCurrentDay == this.ReportStartDate.Day)
                            {
                                arrDayRows.Add(arrRow);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error Occured at method JobControl::SaveDetailReport\n" + ex.Message);
                    }
                }
            } else if (this.Rp == DataBridge.UsageReportRetroactiveProcess.Yes) {
                while (!readerDetail.EndOfStream)
                {
                    try
                    {
                        string strStream = readerDetail.ReadLine().Replace("\",\"", "¦");
                        string strRow = string.Concat(db.StrEANumber + "¦", strStream.Replace("\"", ""));
                        string[] arrRow = strRow.Split('¦');
                        if (arrRow.Length == 30)
                        {
                            int iCurrentDay;
                            if (int.TryParse(arrRow[9], out iCurrentDay))
                            {
                                arrDayRows.Add(arrRow);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error Occured at method JobControl::SaveDetailReport\n" + ex.Message);
                    }
                }
            }

            if (arrDayRows.Count > 0)
            {
                if (dp.ResetBillingDayDetail(db.StrEANumber, this.ReportStartDate, this.Rp) >= 0)
                {
                    foreach (string[] strRow in arrDayRows)
                    {
                        dp.SaveDayDetailReport(strRow);
                    }
                }
            }
        }
        #endregion

    }
}
