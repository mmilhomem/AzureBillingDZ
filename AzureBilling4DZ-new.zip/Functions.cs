﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;

namespace AzureBilling4DZ
{
    public class Functions
    {
        public static void CollectReports([QueueTrigger("queue")] string message, TextWriter log)
        {
            try
            {
                //Core.DataBridge.UsageReportRetroactiveProcess isRetroactive = (Core.DataBridge.UsageReportRetroactiveProcess)int.Parse(Environment.GetEnvironmentVariable("APPSETTING_UsageReportRetroactiveMonthProcess"));
                Core.DataBridge.UsageReportRetroactiveProcess isRetroactive = (Core.DataBridge.UsageReportRetroactiveProcess)int.Parse(System.Configuration.ConfigurationManager.AppSettings["UsageReportRetroactiveMonthProcess"]);
                Core.JobControl jc = new Core.JobControl(isRetroactive);
                jc.Collect();
            }
            catch (Exception ex)
            { Console.WriteLine("Error Occured at method Functions::CollectReports\n" + ex.Message); }
            log.WriteLine(message);
        }
    }
}
